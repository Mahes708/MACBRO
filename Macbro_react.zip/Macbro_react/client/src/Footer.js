import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
            <div>
                 <footer className="footer">
                     © 2019 - 2020 <b>Macbro</b> <span className="d-none d-sm-inline-block"> - Crafted with <i className="mdi mdi-heart text-danger"></i> by Macbro Team.</span>
                </footer>
                
            </div>
        );
    }
}

export default Footer;