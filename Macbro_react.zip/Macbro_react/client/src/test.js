import React from "react";
const Greek = (props) => {
    console.log(props)
    
    return <h1>Name :  {props.name}</h1>    
}


// function Greek(props) {
//     return <h1>Hello, {props.name}</h1>;
//   }
export default Greek;